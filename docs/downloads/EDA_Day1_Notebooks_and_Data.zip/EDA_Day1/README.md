# EDA Day 1: notebooks and data

Extract this whole folder and open it in Positron. In the terminal, run:

    uv sync

Select the .venv Python interpreter as the notebook kernel.

Instructor live coding: notebooks/titanic_live_scaffold.ipynb
Instructor reference: notebooks/titanic_complete.ipynb
Student investigation: notebooks/tornadoes_starter.ipynb
Optional syntax support: notebooks/plotting_reference.ipynb

Keep the data/ directory next to notebooks/. Data load locally after setup.
Tornado coverage is 2015-2018. See data/data_dictionary.md and data/SOURCES.md.
